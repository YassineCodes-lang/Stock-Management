
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

--
-- Database: `stockmanage`
--

Create database stockmanage;
use stockmanage;

--
-- Table structure for table `stocks`
--

CREATE TABLE `stocks` (
  id int NOT NULL,
  item_id varchar(5) DEFAULT NULL,
  name varchar(50) DEFAULT NULL,
  price decimal(10,2) DEFAULT NULL,
  quantity int DEFAULT NULL,
  category varchar(100) DEFAULT NULL,
  date datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=Aria DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Insert into table `stocks`
--

INSERT INTO `stocks` (`id`, `item_id`, `name`, `price`, `quantity`, `category`) VALUES
(1, '731-M', 'Case', '700', '100', 'Computer Components'),
(2, '426-B', 'Processor', '6000', '50', 'Computer Components'),
(3, '167-S', 'Motherboard', '3000', '90', 'Computer Components'),
(4, '344-A', 'Mouse', '600', '125', 'Peripherals'),
(5, '543-C', 'Mechanical keyboard', '1200', '110', 'Peripherals'),
(6, '851-Y', 'HD Webcam', '700', '38', 'Peripherals'),
(7, '162-T', 'WI-FI Router', '600', '63', 'Networking Equipment');



ALTER TABLE `stocks`
  ADD PRIMARY KEY (`id`);


--
-- AUTO_INCREMENT for table `stocks`
--
ALTER TABLE `stocks`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

DELIMITER //

CREATE PROCEDURE AddStock(
    IN p_item_id VARCHAR(5),
    IN p_name VARCHAR(50),
    IN p_price DECIMAL(10, 2),
    IN p_quantity INT,
    IN p_category VARCHAR(100)
)
BEGIN
    INSERT INTO stocks (item_id, name, price, quantity, category) 
    VALUES (p_item_id, p_name, p_price, p_quantity, p_category);
END //

DELIMITER ;


DELIMITER //

CREATE PROCEDURE UpdateStock(
    IN p_item_id VARCHAR(5),
    IN p_name VARCHAR(50),
    IN p_price DECIMAL(10, 2),
    IN p_quantity INT,
    IN p_category VARCHAR(100)
)
BEGIN
    UPDATE stocks 
    SET name = p_name, price = p_price, quantity = p_quantity, category = p_category 
    WHERE item_id = p_item_id;
END //

DELIMITER ;


DELIMITER //

CREATE PROCEDURE DeleteStock(IN p_item_id VARCHAR(5))
BEGIN
    DELETE FROM stocks WHERE item_id = p_item_id;
END //

DELIMITER ;



DELIMITER //

CREATE PROCEDURE GetAllStocks()
BEGIN
    SELECT item_id, name, price, quantity, category, date FROM stocks ORDER BY id DESC;
END //

DELIMITER ;




